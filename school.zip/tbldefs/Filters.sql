﻿CREATE TABLE [Filters] (
  [ID] AUTOINCREMENT CONSTRAINT [PrimaryKey] PRIMARY KEY UNIQUE NOT NULL,
  [Object Type] VARCHAR (255),
  [Object Name] VARCHAR (255),
  [Filter Name] VARCHAR (50) CONSTRAINT [Filter Name] UNIQUE,
  [Filter String] LONGTEXT ,
  [Sort String] LONGTEXT ,
  [Default] BIT ,
  [Description] LONGTEXT 
)
