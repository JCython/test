﻿CREATE TABLE [Students and Guardians] (
  [StudentID] LONG ,
  [GuardianID] LONG ,
  [Relationship] VARCHAR (30),
  [Emergency Contact] BIT ,
   CONSTRAINT [PrimaryKey] PRIMARY KEY ([StudentID], [GuardianID])
)
