﻿CREATE TABLE [Student Attendance] (
  [ID] AUTOINCREMENT CONSTRAINT [PrimaryKey] PRIMARY KEY UNIQUE NOT NULL,
  [Student] LONG ,
  [Attendance Date] DATETIME ,
  [Status] VARCHAR (30)
)
